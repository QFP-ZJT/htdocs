/**
 * Created by QFP_ZJT on 2017/3/6.
 */
function $(id){
    return document.getElementById(id);
}
window.onload = function() {
    alert("欢迎使用js");
    $('lgname').onkeydown = function () {
        if (event.keyCode == 13) {
            $('lgpwd').select();
        }
    }
    $('lgpwd').onkeydown = function () {
        if (event.keyCode == 13) {
            $('lgchk').select();
        }
    }
    $('lgchk').onkeydown = function () {
        if (event.keyCode == 13) {
            chklg();
        }
    }
    $('lgbtn').onclick = chklg;
    function chklg() {
        //登陆发送的内容：姓名（phone）和，密码。
        url = 'login_chk.php?act=' + (Math.random()) + '&name=' + $('lgname').value + '&pwd=' + $('lgpwd').value;
        xmlhttp.open('get', url, true);

        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4) {
                if (xmlhttp.status == 200) {
                    msg = xmlhttp.responseText;
                    if (msg == 0)
                        alert('sorry，您输入的手机号或者密码有误，请核实后输入');
                    else
                        alert('欢迎登陆，' + msg);
                }
            }
        }
        xmlhttp.send(null);
    }
}