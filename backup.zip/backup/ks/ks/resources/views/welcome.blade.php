@extends('layouts.master')

@section('title')
    Welcome!
@endsection

@section('content')
    <div class="col-md-6">
        <h3>登陆</h3>
        <form action = "{{route('a')}}" method="post">
            <div class="form-group">
                <label for="email">请输入您的邮箱地址</label>
                <input class = "form-control" type="text" name="email" id = "email">
            </div>
            <div class="form-group">
                <label for="password">请输入您的密码</label>
                <input class = "form-control" type="password" name="password" id = "password">
            </div>
            <button class="btn btn-primary" type="submit">登陆</button>
        </form>
    </div>
    <div class="col-md-6">
        <h3>注册</h3>
        <form action = "{{route('signUp')}}" method="post">
            <div class="form-group">
                <label for="email">请输入您的邮箱地址</label>
                <input class = "form-control" type="text" name="email" id = "email">
            </div>
            <div class="form-group">
                <label for="password">请输入您的密码</label>
                <input class = "form-control" type="password" name="password" id = "password">
            </div>
            <button class="btn btn-primary" type="submit">注册</button>
        </form>
    </div>

@endsection
